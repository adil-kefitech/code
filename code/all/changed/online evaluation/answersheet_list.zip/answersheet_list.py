import datetime
import json
import logging
import random
import traceback
from cProfile import label
from logging import *

from django.contrib import messages
from django.contrib.auth.models import User
from django.db.models import Q
from django.http import Http404, HttpResponse  # witten httpresponse
from django.shortcuts import get_object_or_404  # 404 if object is not exists
from django.shortcuts import render
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from django_filters.rest_framework import DjangoFilterBackend
from iteration_utilities import unique_everseen
from rest_framework import status  # basically sent back status
from rest_framework import generics, renderers, viewsets
from rest_framework.exceptions import APIException
from rest_framework.generics import ListAPIView
from rest_framework.pagination import PageNumberPagination
from rest_framework.permissions import AllowAny
from rest_framework.response import (
    Response,
)  # get a perticular response every thing is okey then give 200 response
from rest_framework.views import APIView  # normal view can written API data
from river.models import State
from river.utils.exceptions import RiverException

from online_evaluation.serializers import *
from util.constants import *
from util.file_storage import FileStorage
from util.models import *
from util.pagination import *
from util.serializers import *

# CourseList, ExamcodeSerializer, PrintLogListSlzr


class AnswersheetList(ListAPIView):
    def get(self, request):
        try:
            user = request.user

            sub_section_objs = (
                SubsectionProgramme.objects.filter(
                    sub_section__staffsection__staff__user=user
                )
                .select_related(
                    "programme",
                    "programme__programme_type",
                    "programme__programme_group",
                    "programme__programme_class",
                )
                .all()
            )

            data = SubSectionSerializer(sub_section_objs, many=True).data
            pgmtl = unique_everseen([i.get("pgmt") for i in data])
            pgmgl = unique_everseen([i.get("pgmg") for i in data])
            pgmcl = unique_everseen([i.get("pgmc") for i in data])

            return format_response(
                True,
                FETCH_SUCCESS_MSG,
                data={"pgmt": pgmtl, "pgmg": pgmgl, "pgmc": pgmcl},
                status_code=status.HTTP_201_CREATED,
                template_name="uploading_answer_sheet_list.html",
            )
        except Exception as e:
            logger.error(e, exc_info=True)
            return format_response(
                False,
                BAD_GATEWAY,
                {},
                BAD_GATEWAY_ERROR_CODE,
                status_code=status.HTTP_400_BAD_REQUEST,
                template_name="uploading_answer_sheet_list.html",
            )

    def post(self, request):
        try:
            jsondata = request.data
            print(jsondata)
            pgm = jsondata["pgm"]
            clg = jsondata["college"]
            bundle = jsondata["bundle"]
            print(bundle)

            ans = (
                ScannedAnswersheet.objects.filter(bundle_id=bundle)
                .exclude(status__label=DELETE)
                .all()
            )
            print(ans)
            ansl = SASerializer(ans, many=True)
            print("answers", ansl.data)
            return format_response(
                True,
                FETCH_SUCCESS_MSG,
                data={"al": ansl.data},
                status_code=status.HTTP_201_CREATED,
                template_name="uploading_answer_sheet_list.html",
            )
        except Exception as e:
            logger.error(e, exc_info=True)
            return format_response(
                False,
                BAD_GATEWAY,
                {},
                BAD_GATEWAY_ERROR_CODE,
                status_code=status.HTTP_400_BAD_REQUEST,
                template_name="uploading_answer_sheet_list.html",
            )


class ManualMapping(ListAPIView):
    def get(self, request):
        try:
            jsondata = request.GET.get
            ansht = jsondata("ansl")
            ansid = jsondata("ansr")
            scanned_anwersheet = ScannedAnswersheet.objects.filter(
                id=ansid
            ).first()
            if scanned_anwersheet:
                dfm = scanned_anwersheet.dfm_id
                if dfm:

                    bundle_candidate = BundleCandidateMapper.objects.filter(
                        digital_false_no=dfm
                    ).first()
                    if bundle_candidate:
                        seq = bundle_candidate.sequence_no
                    else:
                        seq = "NA"
                else:
                    seq = "NA"
                stat = scanned_anwersheet.status.label

            return format_response(
                True,
                "success",
                data={"id": ansid, "ansl": ansht, "seqn": seq, "stats": stat},
                status_code=status.HTTP_201_CREATED,
                template_name="uploading_answer_sheet_list.html",
            )
        except Exception as e:
            logger.error(e, exc_info=True)
            return format_response(
                False,
                BAD_GATEWAY,
                {},
                BAD_GATEWAY_ERROR_CODE,
                status_code=status.HTTP_400_BAD_REQUEST,
                template_name="uploading_answer_sheet_list.html",
            )

    def post(self, request):
        try:

            encr = request.POST.get("enc")
            ansheet = request.POST.get("id")
            with open("fernet_key.pem", "r") as hfile:
                private_key = hfile.read()
            f = Fernet(private_key)
            lenth = len(encr) - 1
            myStr = encr[2:lenth]
            decrypted_message = f.decrypt((str(myStr).encode()))
            message = decrypted_message.decode()
            qpcode = message.split("|")
            digi = DigitalFalseNumber.objects.get(
                exam_registration_course_id=qpcode[0]
            )
            pending_status = State.objects.get(label=PENDING)
            answersheet = ScannedAnswersheet.objects.filter(id=ansheet).first()
            student_present = DigitalFalseNumber.objects.filter(
                id=digi.id, exam_registration_course__status__label=PRESENT
            ).exists()
            if not student_present:
                return format_response(
                    False,
                    STUDENT_NOT_PRESENT,
                    data={},
                    status_code=status.HTTP_400_BAD_REQUEST,
                    template_name="uploading_answer_sheet_list.html",
                )
            if answersheet:

                answersheet.dfm = digi
                answersheet.status = pending_status
                answersheet.save()

            return format_response(
                True,
                "success",
                status_code=status.HTTP_201_CREATED,
                template_name="uploading_answer_sheet_list.html",
            )
        except Exception as e:
            logger.error(e, exc_info=True)
            return format_response(
                False,
                BAD_GATEWAY,
                {},
                BAD_GATEWAY_ERROR_CODE,
                status_code=status.HTTP_400_BAD_REQUEST,
                template_name="uploading_answer_sheet_list.html",
            )


class DeleteAnswersheet(ListAPIView):
    def put(self, request):

        try:
            updated_by = request.user
            updated_on = timezone.now()
            jsondata = request.data

            ansht = jsondata["ansi"]

            deletestatus = State.objects.get(label=DELETE)
            scanned_answersheet = ScannedAnswersheet.objects.filter(
                id=ansht
            ).last()
            scanned_answersheet.updated_by = updated_by
            scanned_answersheet.updated_on = updated_on
            scanned_answersheet.status = deletestatus
            scanned_answersheet.save()

            return format_response(
                True,
                "success",
                status_code=status.HTTP_201_CREATED,
                template_name="uploading_answer_sheet_list.html",
            )
        except Exception as e:
            logger.error(e, exc_info=True)
            return format_response(
                False,
                BAD_GATEWAY,
                {},
                BAD_GATEWAY_ERROR_CODE,
                status_code=status.HTTP_400_BAD_REQUEST,
                template_name="uploading_answer_sheet_list.html",
            )


class VerifyAnswerSheetList(APIView):
    def get(self, request):
        try:
            user = request.user
            today = timezone.now().date()
            camp_allocations = CampRoleAllocation.objects.filter(
                camp_user=user,
                camp_schedule__status__label__iexact="ACTIVE",
                camp_schedule__start_date__lte=today,
                camp_schedule__end_date__gte=today,
            ).select_related(
                "camp_schedule",
                "camp_schedule__sub_camp",
                "camp_schedule__sub_camp__camp",
            )
            
            camp_list = []
            seen = set()
            for alloc in camp_allocations:
                sched = alloc.camp_schedule
                if sched.id not in seen:
                    seen.add(sched.id)
                    camp_list.append(
                        {
                            "camp_schedule_id": sched.id,
                            "display_name": sched.camp_display_name,
                            "sub_camp_id": sched.sub_camp.id,
                            "sub_camp_name": sched.sub_camp.name,
                            "camp_id": sched.sub_camp.camp.id,
                            "camp_name": sched.sub_camp.camp.camp_name,
                        }
                    )

            return format_response(
                True,
                FETCH_SUCCESS_MSG,
                data={"active_camps": camp_list},
                status_code=status.HTTP_200_OK,
                template_name="uploading_answer_sheet_list.html",
            )
        except Exception as e:
            logger.error(e, exc_info=True)
            return format_response(
                False,
                BAD_GATEWAY,
                {},
                BAD_GATEWAY_ERROR_CODE,
                status_code=status.HTTP_400_BAD_REQUEST,
                template_name="uploading_answer_sheet_list.html",
            )

    def post(self, request):
        try:
            updated_by = request.user
            today = timezone.now().date()

            ver = request.data.get("ver", "")
            verl = ver.split(",")
            if verl and verl[0] == "on":
                del verl[0]

            camp_schedule_id = request.data.get("camp_schedule_id")
            if not camp_schedule_id:
                return format_response(
                    False,
                    "Please select a camp before approving the answersheets.",
                    {},
                    BAD_GATEWAY_ERROR_CODE,
                    status_code=status.HTTP_400_BAD_REQUEST,
                    template_name="uploading_answer_sheet_list.html",
                )

            camp_role_alloc = CampRoleAllocation.objects.filter(
                camp_user=updated_by,
                camp_schedule_id=camp_schedule_id,
                camp_schedule__status__label=ACTIVE,
                camp_schedule__start_date__lte=today,
                camp_schedule__end_date__gte=today,
            ).select_related(
                "camp_schedule__sub_camp__camp"
            ).first()

            if not camp_role_alloc:
                return format_response(
                    False,
                    "Selected camp is not active or you are not allocated to it.",
                    {},
                    BAD_GATEWAY_ERROR_CODE,
                    status_code=status.HTTP_400_BAD_REQUEST,
                    template_name="uploading_answer_sheet_list.html",
                )

            selected_camp_schedule = camp_role_alloc.camp_schedule
            selected_sub_camp = selected_camp_schedule.sub_camp   
            selected_camp = selected_sub_camp.camp               

            active_state = State.objects.get(label=ACTIVE)
            approved_count = 0

            for i in verl:
                i = i.strip()
                if not i:
                    continue
                try:
                    appl = ScannedAnswersheet.objects.get(pk=int(i))
                except (ScannedAnswersheet.DoesNotExist, ValueError):
                    continue

                if appl.status.label == "PENDING":
                    appl.status = active_state
                    appl.updated_by = updated_by
                    appl.save()
                    approved_count += 1

                    if appl.dfm:
                        bundle_cand = BundleCandidateMapper.objects.filter(
                            digital_false_no=appl.dfm
                        ).select_related("bundle").first()

                        if bundle_cand:
                            bundle = bundle_cand.bundle
                            BundleCamp.objects.get_or_create(
                                bundle=bundle,
                                camp=selected_camp,
                                defaults={"sub_camp": selected_sub_camp},
                            )

            return format_response(
                True,
                FETCH_SUCCESS_MSG,
                data={"approved_count": approved_count},
                status_code=status.HTTP_201_CREATED,
                template_name="uploading_answer_sheet_list.html",
            )
        except Exception as e:
            logger.error(e, exc_info=True)
            return format_response(
                False,
                BAD_GATEWAY,
                {},
                BAD_GATEWAY_ERROR_CODE,
                status_code=status.HTTP_400_BAD_REQUEST,
                template_name="uploading_answer_sheet_list.html",
            )
        