from django.urls import path,include

from .import course_registration_report, remuneration,registration_count,techrrenum_list,teacher_count,qp_report

urlpatterns = [
    
     #--------------coursewise students list--------------------------------------------#
    path('api/v1/report/collegewiseadmissionyear',course_registration_report.CollegewiseAdmissionyear.as_view(),name='collegewiseadmissionyear'),    
    path('api/v1/report/collegewiseProgrammeList',course_registration_report.CollegewiseProgrammeList.as_view(),name='collegewiseprogrammeList'),    
    path('api/v1/report/semesterselect',course_registration_report.Semesterselect.as_view(),name='coursewise-student-semesterselect'),    
    path('api/v1/report/programmesemwisecourselist',course_registration_report.Programmesemwisecourselist.as_view(),name='programmesemwisecourselist'),    
    path('api/v1/report/coursewisestudentlist',course_registration_report.CoursewiseStudentlist.as_view(),name='coursewisestudentlist'),

    path('remuneration',remuneration.RemunerationView.as_view(),name='remuneration-view'),

##----Registration count------------
    path('registration-count',registration_count.ExamRegCountPrgmType.as_view(),name='registration-count'),
    path('registration-count-prgmgrp',registration_count.ExamRegCountPrgmGroup.as_view(),name='registration-count-prgmgrp'),
    path('registration-count-prgmscheme',registration_count.ExamRegCountPrgmSchemes.as_view(),name='registration-count-prgmscheme'),
    path('registration-count-exam',registration_count.ExamRegCountExaminations.as_view(),name='registration-count-exam'),
    path('registration-count-view',registration_count.ExamRegCountView.as_view(),name='registration-count-view'),
    path('registration-count-print',registration_count.ExamRegCountPrint.as_view(),name='registration-count-print'),

# ---------------------------------------------Teacher Count----------------------------------------
    path('teacher-count',teacher_count.ProgrammeTypeFetch.as_view(),name='teacher-count'),
    path('section-teacher-count',teacher_count.SectionLevelProgrammeTypeFetch.as_view(),name='section-teacher-count'),
    path('teacher-count-group-fetch',teacher_count.ProgrammeGroupFetch.as_view(),name='teacher-count-group-fetch'),
    path('teacher-count-class-fetch',teacher_count.ProgrammeClassFetch.as_view(),name='teacher-count-class-fetch'),
    path('teacher-count-programme-fetch',teacher_count.TeacherCountProgrammeFetch.as_view(),name='teacher-count-programme-fetch'),
    path('teacher-count-semester-fetch',teacher_count.TeacherCountSemesterFetch.as_view(),name='teacher-count-semester-fetch'),
    path('teacher-count-academic-year',teacher_count.TeacherCountAcademicYear.as_view(),name='teacher-count-academic-year'),
    path('teacher-count-course-list',teacher_count.TeacherCountCourseList.as_view(),name='teacher-count-course-list'),
    path('teacher-count-list-report',teacher_count.TeacherCountListReport.as_view(),name ='teacher-count-list-report'),
    path('teacher-count-teachers-save',teacher_count.TeacherCountListCEApproval.as_view(),name='teacher-count-teachers-save'),
    path('teacher-count-teachers-final-report',teacher_count.TeacherCountApprovedFinalReport.as_view(),name='teacher-count-teachers-final-report'),

#-------------------------------------------------------Teacher Count Section------------------------------------------------------------------
    
    path('section-teacher-count-view',teacher_count.TeacherCountFinalApprovedListSectionView.as_view(),name='section-teacher-count-view'),
    path('section-teacher-count-detailed-view',teacher_count.TeacherCountFinalApprovedSectionView.as_view(),name='section-teacher-count-detailed-view'),
    path('section-teacher-count-generate-view',teacher_count.TeacherCountReportGenerate.as_view(),name='section-teacher-count-generate-view'),
    path('section-teacher-count-generated-report',teacher_count.TeacherCountGeneratedReport.as_view(),name='section-teacher-count-generate-report'),
    path('yearly-teacher-transfer',teacher_count.YearlyTeacherTransferReport.as_view(),name='yearly-teacher-transfer'),

#-----------------------------------------------------------------------------------------------------
    path('tchr-camp-fetch',techrrenum_list.TchrCampfetch.as_view(),name='tchr-camp-fetch'),
    path('tchr-camp-submit',techrrenum_list.TchrCampSubmit.as_view(),name='tchr-camp-submit'),
    path('tchr-renum-approve',techrrenum_list.Tchrapprove.as_view(),name='tchr-renum-approve'),

#----------------------------------------------------------------- Index Card List -------------------------------------------------------------------
    path('teacher-profile-updation-list',teacher_count.ProfileUpdateListAcademicYear.as_view(),name='teacher-profile-updation-list'),
    path('teacher-profile-updation-list-term',teacher_count.ProfileUpdateListTerm.as_view(),name='teacher-profile-updation-list-term'),
    path('teacher-profile-updation-list-district',teacher_count.ProfileUpdateListDistrict.as_view(),name='teacher-profile-updation-list-district'),
    path('teacher-profile-updation-list-college',teacher_count.ProfileUpdateListCollege.as_view(),name='teacher-profile-updation-list-college'),
    path('teacher-profile-updation-list-teachers',teacher_count.ProfileUpdateListTeachers.as_view(),name='teacher-profile-updation-list-teachers'),

#----------------------------------------------------------------- Camp Change ---------------------------------------------------------------------
    path('teacher-preferred-camp',teacher_count.TeacherPreferredCamp.as_view(),name='teacher-preferred-camp'),
    path('teacher-preferred-camp-change',teacher_count.TeacherPreferredCampChange.as_view(),name='teacher-preferred-camp-change'),

#---------------------------------------------------------------- Profile Change --------------------------------------------------------------------
    path('teacher-profile-details-change',teacher_count.TeacherProfileChange.as_view(),name='teacher-profile-details-change'),

#---------------------------------------------------------------- Department wise -------------------------------------------------------------------#
    path('college-department-teacher-report',teacher_count.CollegeDepartmentWiseReport.as_view(),name='college-department-teacher-report'),
    path('districtwise-college',teacher_count.DistrictwiseCollege.as_view(),name='districtwise-college'),
    path('college-level-departments',teacher_count.CollegeLevelDepartments.as_view(),name='college-level-departments'),
    path('dept-level-teachers',teacher_count.DepartmentLevelTeachers.as_view(),name='dept-level-teachers'),

#------------------------------------------------------------ Exam Registration Report --------------------------------------------------------------#
    path('exam-student-registration-report',registration_count.ExamRegStudentCount.as_view(),name='exam-student-registration-report'),
    path('exam-college-student-registration-report',registration_count.ExamRegCollegeStudentCount.as_view(),name='exam-college-student-registration-report'),
    path('exam-course-student-registration-report',registration_count.ExamRegCourseStudentCount.as_view(),name='exam-course-student-registration-report'),

#------------------------------------------------------------ QP Reports -------------------------------------------------------------------#

    path('qp-report-by-exam-code', qp_report.QPReportByExamCode.as_view(), name='qp-report-by-exam-code'),
    path('qp-report-by-qp-code', qp_report.QPReportByQPCode.as_view(), name='qp-report-by-qp-code'),
    # Page that hosts both features (GET renders the combined template)
    path('qp-report', qp_report.QPReportByExamCode.as_view(), name='qp-report'),
]